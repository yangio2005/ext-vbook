load('config.js');
function execute(query, page) {
    query = query || "";
    page = page || "1";

    var docs = [];
    var token = "";
    do {
        var result = listCollection("stories", 300, token);
        if (result.fsError) return Response.error(result.fsError);
        docs = docs.concat(result.docs);
        token = result.nextPageToken;
    } while (token && docs.length < 500);
    docs = sortByUpdatedDesc(docs);

    var items = [];
    for (var i = 0; i < docs.length; i++) {
        if (query && String(docs[i].fields.genres || []).indexOf(query) === -1) continue;
        items.push(storyFields(docs[i]));
    }

    var start = (parseInt(page, 10) - 1) * 20;
    var slice = items.slice(start, start + 20);
    var next = items.length > start + 20 ? String(parseInt(page, 10) + 1) : "";
    return Response.success(slice, next);
}
